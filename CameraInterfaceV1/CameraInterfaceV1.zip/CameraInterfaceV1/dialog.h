#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QMdiSubWindow>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();
    QPushButton *save_pushButton;

signals:
    void sendMessage(const QString &msg);

private slots:
    void on_save_pushButton_clicked();

private:
    Ui::Dialog *ui;
};

#endif // DIALOG_H
