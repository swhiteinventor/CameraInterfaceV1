#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include "dialog2.h"

#include <QCameraInfo>
#include <QCameraViewfinder>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    bool haveCameras = checkCameraAvailability();
    if (haveCameras)
    {
        const QList<QCameraInfo> availableCameras = QCameraInfo::availableCameras();
        QListIterator<QCameraInfo> i(availableCameras);
        QCamera* cameraHead = new QCamera(i.next());
        cameraHead->setViewfinder(ui->viewfinderHead);
        cameraHead->start();
        QCamera* cameraArm = new QCamera(i.next());
        cameraArm->setViewfinder(ui->viewfinderArm);
        cameraArm->start();


        //camera->start();

    }


    }

MainWindow::~MainWindow()
{
    delete ui;
}

bool MainWindow::checkCameraAvailability()
{
    if (QCameraInfo::availableCameras().count() > 1)
        return true;
    else
        return false;
}

void MainWindow::on_addNewView_pushButton_clicked()
{
    Dialog secdialog;
    secdialog.setModal(true);
    secdialog.exec();
}

void MainWindow::on_SetPoint_ViewsButton_clicked()
{
    Dialog2 secdialog2;
    secdialog2.setModal(true);
    secdialog2.exec();
}

